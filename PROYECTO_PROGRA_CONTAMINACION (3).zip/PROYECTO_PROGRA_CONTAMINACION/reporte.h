#include "zona.h"

/* Guarda el reporte final */
void guardarReporte(struct Zona zonas[]);
