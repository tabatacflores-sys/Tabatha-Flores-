#include "reporte.h"
#include <stdio.h>
#include <string.h>


void guardarReporte(struct Zona zonas[]) {
    FILE *archivo;
    int posicionZona, posicionDia;
    float promedioCO2, promedioSO2, promedioNO2, promedioPM25;

    archivo = fopen("reportes.txt", "w");

    if (archivo == NULL) {
        printf("Error al crear reportes.txt\n");
        return;
    }

    for (posicionZona = 0; posicionZona < ZONAS; posicionZona++) {
        // Calcular los promedios históricos para cada zona
        promedioCO2 = 0;
        promedioSO2 = 0;
        promedioNO2 = 0;
        promedioPM25 = 0;

        for (posicionDia = 0; posicionDia < DIAS; posicionDia++) {
            promedioCO2 += zonas[posicionZona].co2[posicionDia];
            promedioSO2 += zonas[posicionZona].so2[posicionDia];
            promedioNO2 += zonas[posicionZona].no2[posicionDia];
            promedioPM25 += zonas[posicionZona].pm25[posicionDia];
        }

        // Calcular el promedio real
        promedioCO2 /= DIAS;
        promedioSO2 /= DIAS;
        promedioNO2 /= DIAS;
        promedioPM25 /= DIAS;

        // Escribir el reporte en el archivo
        fprintf(archivo, "Reporte para la zona: %s\n", zonas[posicionZona].nombre);
        fprintf(archivo, "---------------------------------\n");
        fprintf(archivo, "Promedio CO2 (últimos 30 días): %.2f\n", promedioCO2);
        fprintf(archivo, "Promedio SO2 (últimos 30 días): %.2f\n", promedioSO2);
        fprintf(archivo, "Promedio NO2 (últimos 30 días): %.2f\n", promedioNO2);
        fprintf(archivo, "Promedio PM2.5 (últimos 30 días): %.2f\n", promedioPM25);
        fprintf(archivo, "---------------------------------\n");
    }

    fclose(archivo);
}

