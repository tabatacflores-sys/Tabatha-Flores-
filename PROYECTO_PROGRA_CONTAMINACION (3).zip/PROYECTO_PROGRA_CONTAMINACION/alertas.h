#include "zona.h"

/* Genera alertas y guarda reporte final */
void generarAlertas(struct Zona zonas[]);
