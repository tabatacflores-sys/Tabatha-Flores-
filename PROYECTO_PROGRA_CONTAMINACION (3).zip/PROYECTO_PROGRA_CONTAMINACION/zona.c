#include "zona.h"
#include <string.h>
#include <stdio.h>

void inicializarZonas(struct Zona zonas[])
{
    int posicionZona;
    int posicionDia;

    /* Nombres de las zonas */
    char nombresZonas[ZONAS][30] =
    {
        "Belisario",
        "Carapungo",
        "Centro",
        "Cotocollao",
        "ElCamal"
    };

    /* Recorre cada zona */
    for (posicionZona = 0; posicionZona < ZONAS; posicionZona++)
    {
        /* Asignar nombre de la zona */
        strcpy(zonas[posicionZona].nombre, nombresZonas[posicionZona]);

        /* Inicializar promedios */
        zonas[posicionZona].promedioCO2 = 0;
        zonas[posicionZona].promedioSO2 = 0;
        zonas[posicionZona].promedioNO2 = 0;
        zonas[posicionZona].promedioPM25 = 0;

        /* Inicializar predicción */
        zonas[posicionZona].prediccionCO2 = 0;
        zonas[posicionZona].prediccionSO2 = 0;
        zonas[posicionZona].prediccionNO2 = 0;
        zonas[posicionZona].prediccionPM25 = 0;

        /* Inicializar datos climáticos */
        zonas[posicionZona].temperatura = 0;
        zonas[posicionZona].humedad = 0;
        zonas[posicionZona].viento = 0;

        /* Inicializar históricos de 30 días */
        for (posicionDia = 0; posicionDia < DIAS; posicionDia++)
        {
            zonas[posicionZona].co2[posicionDia] = 0;
            zonas[posicionZona].so2[posicionDia] = 0;
            zonas[posicionZona].no2[posicionDia] = 0;
            zonas[posicionZona].pm25[posicionDia] = 0;
        }
    }
}

void cargarHistorico(struct Zona zonas[])
{
    FILE *archivo = fopen("historico.txt", "r");
    if (archivo == NULL)
    {
        printf("No se encontro historico.txt. Se creara uno al guardar datos.\n");
        return;
    }

    char fecha[11], zonaNombre[30];
    float co2, so2, no2, pm25;

    while (fscanf(archivo, "%10s %s %f %f %f %f", fecha, zonaNombre, &co2, &so2, &no2, &pm25) == 6)
    {
        int posicionZona;
        for (posicionZona = 0; posicionZona < ZONAS; posicionZona++)
        {
            if (strcmp(zonaNombre, zonas[posicionZona].nombre) == 0)
            {
                int posicionDia;
                for (posicionDia = 0; posicionDia < DIAS; posicionDia++)
                {
                    if (zonas[posicionZona].co2[posicionDia] == 0)
                    {
                        zonas[posicionZona].co2[posicionDia] = co2;
                        zonas[posicionZona].so2[posicionDia] = so2;
                        zonas[posicionZona].no2[posicionDia] = no2;
                        zonas[posicionZona].pm25[posicionDia] = pm25;
                        break; // Ya guardamos este registro
                    }
                }
            }
        }
    }

    fclose(archivo);
}

