#include <stdio.h>
#include "predicciones.h"

void calcularPredicciones(struct Zona zonas[]) {
    
    int posicionZona, i;
    float factorClimatico;

    for (posicionZona = 0; posicionZona < ZONAS; posicionZona++)
    {
        float sumaPesos = 0;
        float sumaCO2 = 0, sumaSO2 = 0, sumaNO2 = 0, sumaPM25 = 0;
    
        factorClimatico = 1.0;  // Inicializamos el factor climático (sin ajuste al principio)

        // Ajustes climáticos: temperatura, viento y humedad
        if (zonas[posicionZona].temperatura > 28) {
            factorClimatico += 0.10;  // Aumento por temperatura alta
        }
        if (zonas[posicionZona].viento < 2) {
            factorClimatico += 0.15;  // Aumento por poco viento
        } else if (zonas[posicionZona].viento > 6) {
            factorClimatico -= 0.10;  // Disminución por viento fuerte
        }
        if (zonas[posicionZona].humedad > 70) {
            factorClimatico -= 0.05;  // Disminución por alta humedad
        }

        // Cálculo ponderado de las predicciones
        for (i = 0; i < DIAS; i++)
        {
            int peso = i + 1; // El último día tiene más peso
            sumaCO2 += zonas[posicionZona].co2[i] * peso;
            sumaSO2 += zonas[posicionZona].so2[i] * peso;
            sumaNO2 += zonas[posicionZona].no2[i] * peso;
            sumaPM25 += zonas[posicionZona].pm25[i] * peso;
            sumaPesos += peso;  // Suma de los pesos
        }

        // Calculamos la predicción ajustada por el factor climático
        zonas[posicionZona].prediccionCO2 = (sumaCO2 / sumaPesos) * factorClimatico;
        zonas[posicionZona].prediccionSO2 = (sumaSO2 / sumaPesos) * factorClimatico;
        zonas[posicionZona].prediccionNO2 = (sumaNO2 / sumaPesos) * factorClimatico;
        zonas[posicionZona].prediccionPM25 = (sumaPM25 / sumaPesos) * factorClimatico;
    }
}

void guardarPredicciones(struct Zona zonas[]) {
    FILE *archivo;
    int i;

    archivo = fopen("predicciones.txt", "w");

    if (archivo == NULL) {
        printf("Error al crear predicciones.txt\n");
        return;
    }

    fprintf(archivo, "PREDICCIONES DE CALIDAD DEL AIRE (CO2, SO2, NO2, PM2.5)\n");
    fprintf(archivo, "=======================================================\n\n");

    // Escribimos las predicciones para cada zona
    for (i = 0; i < ZONAS; i++) {
        fprintf(archivo, "Zona: %s\n", zonas[i].nombre);
        fprintf(archivo, "Temperatura: %.1f °C\n", zonas[i].temperatura);
        fprintf(archivo, "Viento: %.1f m/s\n", zonas[i].viento);
        fprintf(archivo, "Humedad: %.1f %%\n", zonas[i].humedad);

        // Escribimos la predicción de cada contaminante
        fprintf(archivo, "Predicción CO2: %.2f ppm\n", zonas[i].prediccionCO2);
        fprintf(archivo, "Predicción SO2: %.2f µg/m3\n", zonas[i].prediccionSO2);
        fprintf(archivo, "Predicción NO2: %.2f µg/m3\n", zonas[i].prediccionNO2);
        fprintf(archivo, "Predicción PM2.5: %.2f µg/m3\n", zonas[i].prediccionPM25);

        // Clasificamos los niveles de predicción de PM2.5
        if (zonas[i].prediccionPM25 <= 15) {
            fprintf(archivo, "Nivel previsto PM2.5: BUENO\n");
        } else if (zonas[i].prediccionPM25 <= 50) {
            fprintf(archivo, "Nivel previsto PM2.5: MODERADO\n");
        } else if (zonas[i].prediccionPM25 <= 100) {
            fprintf(archivo, "Nivel previsto PM2.5: MALO\n");
        } else {
            fprintf(archivo, "Nivel previsto PM2.5: MUY MALO\n");
        }

        // Clasificamos los niveles de CO2
        if (zonas[i].prediccionCO2 <= 1000) {
            fprintf(archivo, "Nivel previsto CO2: BUENO\n");
        } else if (zonas[i].prediccionCO2 <= 2000) {
            fprintf(archivo, "Nivel previsto CO2: MODERADO\n");
        } else {
            fprintf(archivo, "Nivel previsto CO2: PELIGROSO\n");
        }

        // Clasificamos los niveles de SO2
        if (zonas[i].prediccionSO2 <= 40) {
            fprintf(archivo, "Nivel previsto SO2: BUENO\n");
        } else if (zonas[i].prediccionSO2 <= 75) {
            fprintf(archivo, "Nivel previsto SO2: MODERADO\n");
        } else {
            fprintf(archivo, "Nivel previsto SO2: PELIGROSO\n");
        }

        // Clasificamos los niveles de NO2
        if (zonas[i].prediccionNO2 <= 25) {
            fprintf(archivo, "Nivel previsto NO2: BUENO\n");
        } else if (zonas[i].prediccionNO2 <= 50) {
            fprintf(archivo, "Nivel previsto NO2: MODERADO\n");
        } else {
            fprintf(archivo, "Nivel previsto NO2: PELIGROSO\n");
        }

        fprintf(archivo, "-------------------------------------\n\n");
    }

    fclose(archivo);

    printf("Predicciones generadas correctamente en predicciones.txt\n");
}

