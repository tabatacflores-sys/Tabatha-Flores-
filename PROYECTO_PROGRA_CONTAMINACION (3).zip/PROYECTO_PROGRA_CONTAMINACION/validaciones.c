#include <stdio.h>
#include <string.h>
#include "validaciones.h"

/* ================= ENTERO POSITIVO ================= */

int ingresarEnteroPositivo(char *mensaje)
{
    int valor;

    printf("%s: ", mensaje);

    while (scanf("%d", &valor) != 1 || valor <= 0)
    {
        while (getchar() != '\n');
        printf("Debe ser un entero positivo.\n");
        printf("%s: ", mensaje);
    }

    return valor;
}

/* ================= ENTERO EN RANGO ================= */

int ingresarEnteroEnRango(char *mensaje, int minimo, int maximo)
{
    int valor;

    printf("%s (%d - %d): ", mensaje, minimo, maximo);

    while (scanf("%d", &valor) != 1 || valor < minimo || valor > maximo)
    {
        while (getchar() != '\n');
        printf("Debe estar entre %d y %d.\n", minimo, maximo);
        printf("%s (%d - %d): ", mensaje, minimo, maximo);
    }

    return valor;
}

/* ================= FLOTANTE POSITIVO ================= */

float ingresarFlotantePositivo(char *mensaje)
{
    float valor;

    printf("%s: ", mensaje);

    while (scanf("%f", &valor) != 1 || valor < 0)
    {
        while (getchar() != '\n');
        printf("Debe ser un numero positivo.\n");
        printf("%s: ", mensaje);
    }

    return valor;
}

/* ================= CADENA ================= */

void ingresarCadena(char *mensaje, char *cadena, int tamano)
{
    printf("%s: ", mensaje);
    fflush(stdin);
    fgets(cadena, tamano, stdin);
    cadena[strcspn(cadena, "\n")] = '\0';
}

/*================ FECHA VALIDA ===============*/
int esFechaValida(int dia, int mes, int anio)
{
    if (anio < 2000 || mes < 1 || mes > 12 || dia < 1)
        return 0;

    int diasMes[] = {31,28,31,30,31,30,31,31,30,31,30,31};
    // Año bisiesto
    if ((anio%4==0 && anio%100!=0) || (anio%400==0))
        diasMes[1] = 29;

    if (dia > diasMes[mes-1])
        return 0;

    return 1;
}


