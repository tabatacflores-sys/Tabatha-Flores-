#include <stdio.h>
#include "promedios.h"

/* Límites OMS */
#define LIM_CO2   1000
#define LIM_SO2   40
#define LIM_NO2   25
#define LIM_PM25  15

void calcularPromedios(struct Zona zonas[])
{
    int posicionZona;
    int posicionDia;
    float sumaCO2, sumaSO2, sumaNO2, sumaPM25;

    for (posicionZona = 0; posicionZona < ZONAS; posicionZona++)
    {
        sumaCO2 = sumaSO2 = sumaNO2 = sumaPM25 = 0;

        for (posicionDia = 0; posicionDia < DIAS; posicionDia++)
        {
            sumaCO2 += zonas[posicionZona].co2[posicionDia];
            sumaSO2 += zonas[posicionZona].so2[posicionDia];
            sumaNO2 += zonas[posicionZona].no2[posicionDia];
            sumaPM25 += zonas[posicionZona].pm25[posicionDia];
        }

        zonas[posicionZona].promedioCO2 = sumaCO2 / DIAS;
        zonas[posicionZona].promedioSO2 = sumaSO2 / DIAS;
        zonas[posicionZona].promedioNO2 = sumaNO2 / DIAS;
        zonas[posicionZona].promedioPM25 = sumaPM25 / DIAS;

        printf("\n--- Zona: %s ---\n", zonas[posicionZona].nombre);

        // CO2
        printf("Promedio CO2: %.2f ppm (", zonas[posicionZona].promedioCO2);
        if (zonas[posicionZona].promedioCO2 <= LIM_CO2)
            printf("BUENO)\n");
        else if (zonas[posicionZona].promedioCO2 <= LIM_CO2 * 2)
            printf("MODERADO)\n");
        else
            printf("PELIGROSO)\n");

        // SO2
        printf("Promedio SO2: %.2f ug/m3 (", zonas[posicionZona].promedioSO2);
        if (zonas[posicionZona].promedioSO2 <= LIM_SO2)
            printf("BUENO)\n");
        else if (zonas[posicionZona].promedioSO2 <= LIM_SO2 * 2)
            printf("MODERADO)\n");
        else
            printf("PELIGROSO)\n");

        // NO2
        printf("Promedio NO2: %.2f ug/m3 (", zonas[posicionZona].promedioNO2);
        if (zonas[posicionZona].promedioNO2 <= LIM_NO2)
            printf("BUENO)\n");
        else if (zonas[posicionZona].promedioNO2 <= LIM_NO2 * 2)
            printf("MODERADO)\n");
        else
            printf("PELIGROSO)\n");

        // PM2.5
        printf("Promedio PM2.5: %.2f ug/m3 (", zonas[posicionZona].promedioPM25);
        if (zonas[posicionZona].promedioPM25 <= LIM_PM25)
            printf("BUENO)\n");
        else if (zonas[posicionZona].promedioPM25 <= LIM_PM25 * 2)
            printf("MODERADO)\n");
        else if (zonas[posicionZona].promedioPM25 <= LIM_PM25 * 3)
            printf("MALO)\n");
        else
            printf("PELIGROSO)\n");
    }
}

