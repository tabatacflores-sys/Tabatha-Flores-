#include <stdio.h>

#define DIAS 30
#define ZONAS 5

struct Zona
{
    char nombre[30];

    /* Datos históricos (30 días) */
    float co2[DIAS];
    float so2[DIAS];
    float no2[DIAS];
    float pm25[DIAS];

    /* Promedios históricos */
    float promedioCO2;
    float promedioSO2;
    float promedioNO2;
    float promedioPM25;

    /* Predicción próximas 24 horas */
    float prediccionCO2;
    float prediccionSO2;
    float prediccionNO2;
    float prediccionPM25;

    /* Variables climáticas */
    float temperatura;
    float humedad;
    float viento;
};

/* Funciones */
void inicializarZonas(struct Zona zonas[]);
void cargarHistorico(struct Zona zonas[ZONAS]);