#include <stdio.h>
#include "alertas.h"
#include "zona.h"

/* Límites OMS */
#define LIM_CO2   1000
#define LIM_SO2   40
#define LIM_NO2   25
#define LIM_PM25  15

void generarAlertas(struct Zona zonas[])
{
    FILE *archivo;
    int i;

    archivo = fopen("alertas.txt", "w");

    if (archivo == NULL)
    {
        printf("Error al crear alertas.txt\n");
        return;
    }

    printf("\n===== ALERTAS DE CALIDAD DEL AIRE =====\n");

    for (i = 0; i < ZONAS; i++)
    {
        fprintf(archivo, "\n=====================================\n");
        fprintf(archivo, "Zona: %s\n", zonas[i].nombre);
        fprintf(archivo, "=====================================\n");

        printf("\nZona: %s\n", zonas[i].nombre);

        /* ---------------- CO2 ---------------- */
        fprintf(archivo, "\nCO2 promedio: %.2f ppm\n", zonas[i].promedioCO2);

        if (zonas[i].promedioCO2 <= LIM_CO2)
        {
            fprintf(archivo, "Nivel: BUENO\n");
            fprintf(archivo, "Riesgo: Aire interior adecuado.\n");
            fprintf(archivo, "Recomendacion: Mantener ventilacion normal.\n");
        }
        else if (zonas[i].promedioCO2 <= LIM_CO2 * 2)
        {
            fprintf(archivo, "Nivel: MODERADO\n");
            fprintf(archivo, "Riesgo: Puede causar fatiga y somnolencia.\n");
            fprintf(archivo, "Recomendacion: Incrementar ventilacion.\n");
        }
        else
        {
            fprintf(archivo, "Nivel: PELIGROSO\n");
            fprintf(archivo, "ALERTA ROJA\n");
            fprintf(archivo, "Riesgo: Deficiencia de oxigeno.\n");
            fprintf(archivo, "Recomendacion: Evacuar espacios cerrados.\n");
        }

        /* ---------------- SO2 ---------------- */
        fprintf(archivo, "\nSO2 promedio: %.2f ug/m3\n", zonas[i].promedioSO2);

        if (zonas[i].promedioSO2 <= LIM_SO2)
        {
            fprintf(archivo, "Nivel: BUENO\n");
            fprintf(archivo, "Riesgo: Sin efectos significativos.\n");
            fprintf(archivo,"Recomendacion: Mantener actividades normales al aire libre.\n");
        }
        else if (zonas[i].promedioSO2 <= LIM_SO2 * 2)
        {
            fprintf(archivo, "Nivel: MODERADO\n");
            fprintf(archivo, "Riesgo: Irritacion leve de vias respiratorias.\n");
            fprintf(archivo, "Recomendacion: Personas sensibles deben limitar exposición prolongada.\n");
        }
        else
        {
            fprintf(archivo, "Nivel: PELIGROSO\n");
            fprintf(archivo, "ALERTA ROJA\n");
            fprintf(archivo, "Riesgo: Broncoespasmos y dificultad respiratoria.\n");
            fprintf(archivo, "Recomendacion: Evitar salir, usar mascarilla y reducir emisiones industriales.\n");
        }

        /* ---------------- NO2 ---------------- */
        fprintf(archivo, "\nNO2 promedio: %.2f ug/m3\n", zonas[i].promedioNO2);

        if (zonas[i].promedioNO2 <= LIM_NO2)
        {
            fprintf(archivo, "Nivel: BUENO\n");
               fprintf(archivo, "Riesgo: Sin efectos significativos.\n");
            fprintf(archivo,"Recomendacion: Condiciones normales para la población\n.");
        }
        else if (zonas[i].promedioNO2 <= LIM_NO2 * 2)
        {
            fprintf(archivo, "Nivel: MODERADO\n");
            fprintf(archivo, "Riesgo: Tos e irritacion pulmonar.\n");
            fprintf(archivo, "Recomendacion: Reducir actividad fisica intensa al aire libre.\n");
        }
        else
        {
            fprintf(archivo, "Nivel: PELIGROSO\n");
            fprintf(archivo, "ALERTA ROJA\n");
            fprintf(archivo, "Riesgo: Inflamacion pulmonar.\n");
            fprintf(archivo, "Recomendacion: Permanecer en interiores y evitar trafico vehicular.\n");
        }

        /* ---------------- PM2.5 ---------------- */
        fprintf(archivo, "\nPM2.5 promedio: %.2f ug/m3\n",
                zonas[i].promedioPM25);

        fprintf(archivo, "PM2.5 prediccion 24h: %.2f ug/m3\n",
                zonas[i].prediccionPM25);

        if (zonas[i].prediccionPM25 <= LIM_PM25)
        {
            fprintf(archivo, "Nivel: BUENO\n");
            fprintf(archivo, "Estado: Aire limpio.\n");
            fprintf(archivo, "Recomendacion: Puede realizar actividades al aire libre sin restriccion.\n");
        }
        else if (zonas[i].prediccionPM25 <= LIM_PM25 * 2)
        {
            fprintf(archivo, "Nivel: MODERADO\n");
            fprintf(archivo,
                    "Recomendacion: Personas sensibles deben limitar exposicion.\n");
        }
        else if (zonas[i].prediccionPM25 <= LIM_PM25 * 3)
        {
            fprintf(archivo, "Nivel: MALO\n");
            fprintf(archivo,
                    "Riesgo: Afectacion respiratoria.\n");
            fprintf(archivo,
                    "Recomendacion: Evitar ejercicio al aire libre.\n");
        }
        else
        {
            fprintf(archivo, "Nivel: PELIGROSO\n");
            fprintf(archivo, "ALERTA ROJA\n");
            fprintf(archivo,
                    "Riesgo: Grave impacto pulmonar.\n");
            fprintf(archivo,
                    "Recomendacion: Permanecer en interiores.\n");
        }
    }

    fclose(archivo);

    printf("\nAlertas generadas correctamente en alertas.txt\n");
}


