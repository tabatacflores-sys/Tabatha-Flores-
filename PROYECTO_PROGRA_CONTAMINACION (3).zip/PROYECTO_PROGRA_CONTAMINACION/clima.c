#include <stdio.h>
#include "zona.h"
#include "validaciones.h"

void ingresarDatosZona(struct Zona zonas[], int *anio, int *mes, int *dia)
{
    int posicionZona;

    printf("\n=== INGRESO DE DATOS DIARIOS POR ZONA ===\n");

    // Validar fecha ingresada por el usuario
    do {
        printf("Ingrese la fecha de los datos (DD MM AAAA): ");
        scanf("%d %d %d", dia, mes, anio);
    } while (!esFechaValida(*dia, *mes, *anio));

    for (posicionZona = 0; posicionZona < ZONAS; posicionZona++)
    {
        printf("\nZona: %s\n", zonas[posicionZona].nombre);

        // Datos de contaminación
        zonas[posicionZona].co2[0] =
            ingresarEnteroEnRango("CO2 (ppm)", 0, 2000);

        zonas[posicionZona].so2[0] =
            ingresarEnteroEnRango("SO2 (ug/m3)", 0, 500);

        zonas[posicionZona].no2[0] =
            ingresarEnteroEnRango("NO2 (ug/m3)", 0, 300);

        zonas[posicionZona].pm25[0] =
            ingresarEnteroEnRango("PM2.5 (ug/m3)", 0, 200);

        // Datos climáticos
        zonas[posicionZona].temperatura =
            ingresarEnteroEnRango("Temperatura (°C)", -5, 45);

        zonas[posicionZona].humedad =
            ingresarEnteroEnRango("Humedad (%)", 0, 100);

        zonas[posicionZona].viento =
            ingresarEnteroEnRango("Velocidad del viento (m/s)", 0, 20);
    }
}

/* Guarda los datos de contaminantes en historico.txt usando la fecha ingresada */
void guardarHistorico(struct Zona zonas[], int dia, int mes, int anio)
{
    FILE *archivo = fopen("historico.txt", "a");

    if (archivo == NULL)
    {
        printf("Error al abrir historico.txt\n");
        return;
    }

    int posicionZona;
    for (posicionZona = 0; posicionZona < ZONAS; posicionZona++)
    {
        fprintf(archivo, "%04d-%02d-%02d %s %.0f %.0f %.0f %.0f\n",
                anio, mes, dia,
                zonas[posicionZona].nombre,
                zonas[posicionZona].co2[0],
                zonas[posicionZona].so2[0],
                zonas[posicionZona].no2[0],
                zonas[posicionZona].pm25[0]);
    }

    fclose(archivo);
    printf("\nDatos de contaminantes guardados en historico.txt\n");
}

/* Guarda los datos climáticos en clima.txt usando la fecha ingresada */
void guardarClima(struct Zona zonas[], int dia, int mes, int anio)
{
    FILE *archivo = fopen("clima.txt", "a");

    if (archivo == NULL)
    {
        printf("Error al abrir clima.txt\n");
        return;
    }

    int posicionZona;
    for (posicionZona = 0; posicionZona < ZONAS; posicionZona++)
    {
        fprintf(archivo, "%04d-%02d-%02d %s %.1f %.1f %.1f\n",
                anio, mes, dia,
                zonas[posicionZona].nombre,
                zonas[posicionZona].temperatura,
                zonas[posicionZona].humedad,
                zonas[posicionZona].viento);
    }

    fclose(archivo);
    printf("Datos climáticos guardados en clima.txt\n");
}



