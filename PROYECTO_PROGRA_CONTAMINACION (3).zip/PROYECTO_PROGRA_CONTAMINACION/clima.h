#include "zona.h"
#include "validaciones.h"

void ingresarDatosZona(struct Zona zonas[], int *anio, int *mes, int *dia);
void guardarHistorico(struct Zona zonas[], int anio, int mes, int dia);
void guardarClima(struct Zona zonas[], int anio, int mes, int dia);
