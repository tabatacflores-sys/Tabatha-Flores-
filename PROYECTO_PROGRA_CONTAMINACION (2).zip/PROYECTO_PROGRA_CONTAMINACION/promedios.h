#include "zona.h"

/* Calcula el promedio de los 30 dias */
void calcularPromedios(struct Zona zonas[]);
