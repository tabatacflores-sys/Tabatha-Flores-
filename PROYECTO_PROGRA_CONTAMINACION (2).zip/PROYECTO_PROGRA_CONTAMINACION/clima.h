#include "zona.h"

void ingresarDatosClimaticos(struct Zona zonas[]);
