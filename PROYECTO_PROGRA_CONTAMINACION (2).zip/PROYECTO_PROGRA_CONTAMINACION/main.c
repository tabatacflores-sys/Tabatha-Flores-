#include <stdio.h>

#include "zona.h"
#include "archivos.h"
#include "predicciones.h"
#include "alertas.h"
#include "validaciones.h"
#include "clima.h"
#include "promedios.h"


int main()
{
    struct Zona zonas[ZONAS];

    int opcionMenu;

    /* Inicialización */
    inicializarZonas(zonas);

    /* Cargar datos históricos */
    cargarHistorico(zonas);

    do
    {
        printf("\n===== SISTEMA DE CALIDAD DEL AIRE =====\n");
        printf("1. Calcular promedios historicos\n");
        printf("2. Ingresar datos climaticos\n");
        printf("3. Calcular predicciones\n");
        printf("4. Mostrar alertas\n");
        printf("5. Generar reportes\n");
        printf("6. Salir\n");

        opcionMenu = ingresarEnteroEnRango(
            "Seleccione una opcion",
            1,
            6
        );

        switch (opcionMenu)
        {
            case 1:
                calcularPromedios(zonas);
                printf("Promedios calculados correctamente.\n");
                break;

            case 2:
                ingresarDatosClimaticos(zonas);
                break;

            case 3:
                calcularPredicciones(zonas);
                guardarPredicciones(zonas);
                printf("Predicciones generadas correctamente.\n");
                break;

            case 4:
                generarAlertas(zonas);
                break;

            case 5:
                guardarReporte(zonas);
                printf("Reporte guardado correctamente.\n");
                break;

            case 6:
                printf("Saliendo del sistema...\n");
                break;
        }

    } while (opcionMenu != 6);

    return 0;
}
