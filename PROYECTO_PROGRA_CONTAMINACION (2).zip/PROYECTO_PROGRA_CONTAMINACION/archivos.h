#include "zona.h"

/* Lee los datos históricos desde el archivo */
void leerHistorico(struct Zona zonas[]);

/* Guarda el reporte final */
void guardarReporte(struct Zona zonas[]);
