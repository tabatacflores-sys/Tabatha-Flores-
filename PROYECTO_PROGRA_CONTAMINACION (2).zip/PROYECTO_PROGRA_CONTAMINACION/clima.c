#include <stdio.h>
#include "clima.h"
#include "validaciones.h"

void ingresarDatosClimaticos(struct Zona zonas[])
{
    int posicionZona;

    printf("\n=== INGRESO DE DATOS CLIMATICOS ===\n");

    for (posicionZona = 0; posicionZona < ZONAS; posicionZona++)
    {
        printf("\nZona: %s\n", zonas[posicionZona].nombre);

        zonas[posicionZona].temperatura =
            ingresarEnteroEnRango("Temperatura (°C)", -5, 45);

        zonas[posicionZona].humedad =
            ingresarEnteroEnRango("Humedad (%)", 0, 100);

        zonas[posicionZona].viento =
            ingresarEnteroEnRango("Velocidad del viento (m/s)", 0, 20);
    }
}
