#include "zona.h"
#include <string.h>
#include <stdio.h>

void inicializarZonas(struct Zona zonas[])
{
    int posicionZona;
    int posicionDia;

    /* Nombres de las zonas */
    char nombresZonas[ZONAS][30] =
    {
        "Belisario",
        "Carapungo",
        "Centro",
        "Cotocollao",
        "ElCamal"
    };

    /* Recorre cada zona */
    for (posicionZona = 0; posicionZona < ZONAS; posicionZona++)
    {
        /* Asignar nombre de la zona */
        strcpy(zonas[posicionZona].nombre, nombresZonas[posicionZona]);

        /* Inicializar promedios */
        zonas[posicionZona].promedioCO2 = 0;
        zonas[posicionZona].promedioSO2 = 0;
        zonas[posicionZona].promedioNO2 = 0;
        zonas[posicionZona].promedioPM25 = 0;

        /* Inicializar predicción */
        zonas[posicionZona].prediccionPM25 = 0;

        /* Inicializar datos climáticos */
        zonas[posicionZona].temperatura = 0;
        zonas[posicionZona].humedad = 0;
        zonas[posicionZona].viento = 0;

        /* Inicializar históricos de 30 días */
        for (posicionDia = 0; posicionDia < DIAS; posicionDia++)
        {
            zonas[posicionZona].co2[posicionDia] = 0;
            zonas[posicionZona].so2[posicionDia] = 0;
            zonas[posicionZona].no2[posicionDia] = 0;
            zonas[posicionZona].pm25[posicionDia] = 0;
        }
    }
}

void cargarHistorico(struct Zona zonas[ZONAS]) {
    FILE *archivo = fopen("historico.txt", "r");

    if (archivo == NULL) {
        printf("Error al abrir historico.txt\n");
        return;
    }

    char fecha[11];     // Para la fecha (yyyy-mm-dd)
    char zona[30];      // Para el nombre de la zona
    int co2, so2, no2, pm25;
    int dia = 0;        // Día dentro del mes (0-29)
    int zonaActual = 0; // Usamos 0 para indicar que encontramos una zona válida

    while (fscanf(archivo, "%10s %s %d %d %d %d", fecha, zona, &co2, &so2, &no2, &pm25) == 6) {
        zonaActual = 0;  // Reiniciamos la zona actual

        // Buscar la zona correspondiente
        for (int i = 0; i < ZONAS; i++) {
            if (strcmp(zona, zonas[i].nombre) == 0) {
                zonaActual = i + 1; // Si encontramos la zona, la marcamos como válida
                break;  // Ya encontramos la zona, no necesitamos seguir buscando
            }
        }

        if (zonaActual != 0) {  // Si la zona fue encontrada
            zonas[zonaActual - 1].co2[dia] = co2;  // Restamos 1 para usar un índice válido
            zonas[zonaActual - 1].so2[dia] = so2;
            zonas[zonaActual - 1].no2[dia] = no2;
            zonas[zonaActual - 1].pm25[dia] = pm25;

            dia++;

            // Si ya cargamos los 30 días para la zona, pasamos a la siguiente zona
            if (dia >= DIAS) {
                dia = 0;  // Reiniciar día para la siguiente zona
            }
        } else {
            // Si no encontramos la zona
            printf("Zona '%s' no encontrada en el archivo\n", zona);
        }
    }

    fclose(archivo);
}