#include "zona.h"

/* Calcula la predicción de PM2.5 para cada zona */
void calcularPredicciones(struct Zona zonas[]);

/* Guarda las predicciones en un archivo */
void guardarPredicciones(struct Zona zonas[]);
