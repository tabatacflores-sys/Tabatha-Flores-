#include <stdio.h>
#include <string.h>
#include "validaciones.h"

/* ================= ENTERO POSITIVO ================= */

int ingresarEnteroPositivo(char *mensaje)
{
    int valor;

    printf("%s: ", mensaje);

    while (scanf("%d", &valor) != 1 || valor <= 0)
    {
        while (getchar() != '\n');
        printf("Debe ser un entero positivo.\n");
        printf("%s: ", mensaje);
    }

    return valor;
}

/* ================= ENTERO EN RANGO ================= */

int ingresarEnteroEnRango(char *mensaje, int minimo, int maximo)
{
    int valor;

    printf("%s (%d - %d): ", mensaje, minimo, maximo);

    while (scanf("%d", &valor) != 1 || valor < minimo || valor > maximo)
    {
        while (getchar() != '\n');
        printf("Debe estar entre %d y %d.\n", minimo, maximo);
        printf("%s (%d - %d): ", mensaje, minimo, maximo);
    }

    return valor;
}

/* ================= FLOTANTE POSITIVO ================= */

float ingresarFlotantePositivo(char *mensaje)
{
    float valor;

    printf("%s: ", mensaje);

    while (scanf("%f", &valor) != 1 || valor < 0)
    {
        while (getchar() != '\n');
        printf("Debe ser un numero positivo.\n");
        printf("%s: ", mensaje);
    }

    return valor;
}

/* ================= CADENA ================= */

void ingresarCadena(char *mensaje, char *cadena, int tamano)
{
    printf("%s: ", mensaje);
    fflush(stdin);
    fgets(cadena, tamano, stdin);
    cadena[strcspn(cadena, "\n")] = '\0';
}

