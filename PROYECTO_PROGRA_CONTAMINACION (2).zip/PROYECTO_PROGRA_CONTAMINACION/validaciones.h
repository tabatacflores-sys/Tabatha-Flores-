int ingresarEnteroPositivo(char *mensaje);
int ingresarEnteroEnRango(char *mensaje, int minimo, int maximo);
float ingresarFlotantePositivo(char *mensaje);
void ingresarCadena(char *mensaje, char *cadena, int tamano);
