#include "archivos.h"
#include <stdio.h>
#include <string.h>

void leerHistorico(struct Zona zonas[]) {
    FILE *archivo;
    int posicionZona, posicionDia;
    char fecha[11], nombreZona[30];
    float co2, so2, no2, pm25;
    int zonaEncontrada;  // Bandera para indicar si encontramos la zona
    int diaAsignado;     // Bandera para indicar si el día fue asignado

    archivo = fopen("historico.txt", "r");

    if (archivo == NULL) {
        printf("Error al abrir historico.txt\n");
        return;
    }

    // Recorre cada línea del archivo
    while (fscanf(archivo, "%10s %29s %f %f %f %f", fecha, nombreZona, &co2, &so2, &no2, &pm25) == 6) {
        zonaEncontrada = 0;  // Reiniciamos la bandera de zona
        diaAsignado = 0;     // Reiniciamos la bandera de día asignado

        // Busca la zona correspondiente
        for (posicionZona = 0; posicionZona < ZONAS; posicionZona++) {
            if (strcmp(zonas[posicionZona].nombre, nombreZona) == 0) {
                zonaEncontrada = 1;  // Marcamos que encontramos la zona

                // Asigna los valores a la zona correspondiente
                for (posicionDia = 0; posicionDia < DIAS; posicionDia++) {
                    if (zonas[posicionZona].co2[posicionDia] == 0) {  // Si el día está vacío
                        zonas[posicionZona].co2[posicionDia] = co2;
                        zonas[posicionZona].so2[posicionDia] = so2;
                        zonas[posicionZona].no2[posicionDia] = no2;
                        zonas[posicionZona].pm25[posicionDia] = pm25;
                        diaAsignado = 1;  // Marcamos que el día fue asignado
                        break;  // Terminamos el bucle de días
                    }
                }
                break;  // Terminamos el bucle de zonas
            }
        }

        // Verificamos si encontramos la zona y asignamos el día
        if (!zonaEncontrada) {
            printf("Zona '%s' no encontrada en el archivo\n", nombreZona);
        }

        if (!diaAsignado) {
            printf("No se pudo asignar un día para la zona '%s' con fecha %s\n", nombreZona, fecha);
        }
    }

    fclose(archivo);
}

void guardarReporte(struct Zona zonas[]) {
    FILE *archivo;
    int posicionZona, posicionDia;
    float promedioCO2, promedioSO2, promedioNO2, promedioPM25;

    archivo = fopen("reportes.txt", "w");

    if (archivo == NULL) {
        printf("Error al crear reportes.txt\n");
        return;
    }

    for (posicionZona = 0; posicionZona < ZONAS; posicionZona++) {
        // Calcular los promedios históricos para cada zona
        promedioCO2 = 0;
        promedioSO2 = 0;
        promedioNO2 = 0;
        promedioPM25 = 0;

        for (posicionDia = 0; posicionDia < DIAS; posicionDia++) {
            promedioCO2 += zonas[posicionZona].co2[posicionDia];
            promedioSO2 += zonas[posicionZona].so2[posicionDia];
            promedioNO2 += zonas[posicionZona].no2[posicionDia];
            promedioPM25 += zonas[posicionZona].pm25[posicionDia];
        }

        // Calcular el promedio real
        promedioCO2 /= DIAS;
        promedioSO2 /= DIAS;
        promedioNO2 /= DIAS;
        promedioPM25 /= DIAS;

        // Escribir el reporte en el archivo
        fprintf(archivo, "Reporte para la zona: %s\n", zonas[posicionZona].nombre);
        fprintf(archivo, "---------------------------------\n");
        fprintf(archivo, "Promedio CO2 (últimos 30 días): %.2f\n", promedioCO2);
        fprintf(archivo, "Promedio SO2 (últimos 30 días): %.2f\n", promedioSO2);
        fprintf(archivo, "Promedio NO2 (últimos 30 días): %.2f\n", promedioNO2);
        fprintf(archivo, "Promedio PM2.5 (últimos 30 días): %.2f\n", promedioPM25);
        fprintf(archivo, "---------------------------------\n");
    }

    fclose(archivo);
}

