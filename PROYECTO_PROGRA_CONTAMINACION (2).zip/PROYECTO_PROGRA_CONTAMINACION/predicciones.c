#include <stdio.h>
#include "predicciones.h"

void calcularPredicciones(struct Zona zonas[])
{
    int posicionZona;
    int posicionDia;

    float sumaUltimosDias;
    float promedioBase;
    float factorClimatico;

    for (posicionZona = 0; posicionZona < ZONAS; posicionZona++)
    {
        sumaUltimosDias = 0;

        /* Tomamos los ultimos 5 dias */
        for (posicionDia = DIAS - 5; posicionDia < DIAS; posicionDia++)
        {
            sumaUltimosDias += zonas[posicionZona].pm25[posicionDia];
        }

        promedioBase = sumaUltimosDias / 5;

        /* FACTORES CLIMATICOS */

        factorClimatico = 1.0;

        /* Temperatura */
        if (zonas[posicionZona].temperatura > 28)
        {
            factorClimatico += 0.10;
        }

        /* Viento */
        if (zonas[posicionZona].viento < 2)
        {
            factorClimatico += 0.15;
        }
        else if (zonas[posicionZona].viento > 6)
        {
            factorClimatico -= 0.10;
        }

        /* Humedad */
        if (zonas[posicionZona].humedad > 70)
        {
            factorClimatico -= 0.05;
        }

        zonas[posicionZona].prediccionPM25 = promedioBase * factorClimatico;
    }
}
void guardarPredicciones(struct Zona zonas[])
{
    FILE *archivo;
    int i;

    archivo = fopen("predicciones.txt", "w");

    if (archivo == NULL)
    {
        printf("Error al crear predicciones.txt\n");
        return;
    }

    fprintf(archivo, "PREDICCIONES DE CALIDAD DEL AIRE (PM2.5)\n");
    fprintf(archivo, "=====================================\n\n");

    for (i = 0; i < ZONAS; i++)
    {
        fprintf(archivo, "Zona: %s\n", zonas[i].nombre);

        fprintf(archivo, "Temperatura: %.1f °C\n",
                zonas[i].temperatura);

        fprintf(archivo, "Viento: %.1f m/s\n",
                zonas[i].viento);

        fprintf(archivo, "Humedad: %.1f %%\n",
                zonas[i].humedad);

        fprintf(archivo, "Prediccion PM2.5: %.2f ug/m3\n",
                zonas[i].prediccionPM25);

        if (zonas[i].prediccionPM25 <= 12)
            fprintf(archivo, "Nivel previsto: BUENO\n");
        else if (zonas[i].prediccionPM25 <= 35)
            fprintf(archivo, "Nivel previsto: MODERADO\n");
        else if (zonas[i].prediccionPM25 <= 55)
            fprintf(archivo, "Nivel previsto: MALO\n");
        else
            fprintf(archivo, "Nivel previsto: MUY MALO\n");

        fprintf(archivo,
                "-------------------------------------\n\n");
    }

    fclose(archivo);
}
