#include "zona.h"

/* Calcula las alertas según los niveles de predicción de contaminación */
void generarAlertas(struct Zona zonas[]);
