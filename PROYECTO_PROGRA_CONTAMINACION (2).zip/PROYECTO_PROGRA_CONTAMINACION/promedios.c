#include <stdio.h>
#include "promedios.h"

void calcularPromedios(struct Zona zonas[])
{
    int posicionZona;
    int posicionDia;

    float sumaCO2;
    float sumaSO2;
    float sumaNO2;
    float sumaPM25;

    for (posicionZona = 0; posicionZona < ZONAS; posicionZona++)
    {
        sumaCO2 = 0;
        sumaSO2 = 0;
        sumaNO2 = 0;
        sumaPM25 = 0;

        /* Sumar los 30 dias */
        for (posicionDia = 0; posicionDia < DIAS; posicionDia++)
        {
            sumaCO2 += zonas[posicionZona].co2[posicionDia];
            sumaSO2 += zonas[posicionZona].so2[posicionDia];
            sumaNO2 += zonas[posicionZona].no2[posicionDia];
            sumaPM25 += zonas[posicionZona].pm25[posicionDia];
        }

        /* Calcular promedios */
        zonas[posicionZona].promedioCO2 = sumaCO2 / DIAS;
        zonas[posicionZona].promedioSO2 = sumaSO2 / DIAS;
        zonas[posicionZona].promedioNO2 = sumaNO2 / DIAS;
        zonas[posicionZona].promedioPM25 = sumaPM25 / DIAS;
    }
}
