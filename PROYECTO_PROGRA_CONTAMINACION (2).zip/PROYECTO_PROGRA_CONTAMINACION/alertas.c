#include <stdio.h>
#include "alertas.h"

void generarAlertas(struct Zona zonas[])
{
    int posicionZona;

    printf("\n===== ALERTAS DE CALIDAD DEL AIRE =====\n");

    // Abre el archivo para escribir las alertas
    FILE *archivo = fopen("alertas.txt", "w");

    if (archivo == NULL)
    {
        printf("Error al crear alertas.txt\n");
        return;
    }

    for (posicionZona = 0; posicionZona < ZONAS; posicionZona++)
    {
        printf("\nZona: %s\n", zonas[posicionZona].nombre);
        printf("Prediccion PM2.5: %.2f ug/m3\n",
               zonas[posicionZona].prediccionPM25);

        // Escribir las alertas en el archivo
        fprintf(archivo, "\nZona: %s\n", zonas[posicionZona].nombre);
        fprintf(archivo, "Prediccion PM2.5: %.2f ug/m3\n", zonas[posicionZona].prediccionPM25);

        if (zonas[posicionZona].prediccionPM25 <= 12)
        {
            printf("Nivel: BUENO\n");
            printf("Estado: Aire limpio y saludable.\n");
            fprintf(archivo, "Nivel: BUENO\n");
            fprintf(archivo, "Estado: Aire limpio y saludable.\n");
        }
        else if (zonas[posicionZona].prediccionPM25 <= 35)
        {
            printf("Nivel: MODERADO\n");
            printf("Recomendacion: Personas sensibles deben limitar exposicion prolongada.\n");
            fprintf(archivo, "Nivel: MODERADO\n");
            fprintf(archivo, "Recomendacion: Personas sensibles deben limitar exposicion prolongada.\n");
        }
        else if (zonas[posicionZona].prediccionPM25 <= 55)
        {
            printf("Nivel: MALO\n");
            printf("Alerta: Riesgo para grupos vulnerables.\n");
            printf("Evitar actividad fisica al aire libre.\n");
            fprintf(archivo, "Nivel: MALO\n");
            fprintf(archivo, "Alerta: Riesgo para grupos vulnerables.\n");
            fprintf(archivo, "Evitar actividad fisica al aire libre.\n");
        }
        else
        {
            printf("Nivel: MUY MALO\n");
            printf("ALERTA ROJA\n");
            printf("Riesgo alto para toda la poblacion.\n");
            printf("Permanecer en interiores.\n");
            fprintf(archivo, "Nivel: MUY MALO\n");
            fprintf(archivo, "ALERTA ROJA\n");
            fprintf(archivo, "Riesgo alto para toda la poblacion.\n");
            fprintf(archivo, "Permanecer en interiores.\n");
        }
        fprintf(archivo, "---------------------------------\n");
    }

    // Cerrar el archivo después de escribir
    fclose(archivo);
}

